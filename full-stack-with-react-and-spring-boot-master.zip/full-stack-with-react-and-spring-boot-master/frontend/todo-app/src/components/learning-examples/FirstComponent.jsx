import React, { Component } from 'react'

//Class Component
class FirstComponent extends Component {
  render() {
    return (
      <div className="firstComponent">
        FirstComponent
        </div>
    )
  }
}

export default FirstComponent